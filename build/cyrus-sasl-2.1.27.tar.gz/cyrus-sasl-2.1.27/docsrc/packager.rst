==================
Note for Packagers
==================

People considering doing binary distributions that include saslauthd
should be aware that the code is covered by several slightly different
(but compatible) licenses, due to how it was contributed.  Details can
be found within the source code.
