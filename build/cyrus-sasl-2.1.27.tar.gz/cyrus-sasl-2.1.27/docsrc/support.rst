=================
Support/Community
=================

Please read our support and bug reporting guidelines in the :ref:`Cyrus IMAP project <cyrusimap:support>`.
