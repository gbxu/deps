:orphan:

.. saslman:: CMDNAME(3)

.. _sasl-reference-manpages-library-CMD:

==========
**CMD**
==========

intro...

Synopsis
========

.. parsed-literal::

    **CMD** [ **-C** *config-file* ] [OPTIONS]

Description
===========

**CMD** description...


Options
=======

.. program:: CMD

.. option:: -C config-file

Examples
========

History
=======

Files
=====

See Also
========
