Auxiliary Properties
====================

Auxiliary Properties and the Glue Layer
---------------------------------------

.. todo::
   Content needed here

Passwords and other Data
------------------------

.. todo::
   Content needed here

sasldb
------

.. todo::
   Content needed here

ldapdb
------

.. todo::
   Content needed here

sql
---

.. todo::
   Content needed here

User Canonicalization
---------------------

.. todo::
   Content needed here


