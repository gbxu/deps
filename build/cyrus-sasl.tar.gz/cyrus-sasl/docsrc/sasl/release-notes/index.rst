=============
Release Notes
=============

Latest version is |sasl_current_stable_version|.

Supported Product Series
========================

Series 2.1
----------

.. toctree::
    :maxdepth: 1
    :glob:

    2.1/index

Older Versions
==============

Series 2: 2.0
-------------

.. toctree::
    :maxdepth: 1
    :glob:

    2.0/index

Series 1
--------

.. toctree::
    :maxdepth: 1
    :glob:

    1/index
