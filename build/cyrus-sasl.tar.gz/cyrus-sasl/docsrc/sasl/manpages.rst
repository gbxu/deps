=========
Man pages
=========

(3) Library Files
=======================

.. toctree::
    :maxdepth: 1
    :glob:

    reference/manpages/library/*


..  template.rst: this is just the template for new manpages so it obeys man and html formatting.
