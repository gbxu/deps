# -*- coding: utf-8 -*-
"""
    sphinxlocal.writers
    ~~~~~~~~~~~~~~

    Custom docutils writers.

    :copyright: Copyright 2015 by Nic Bernstein <nic@onlight.com>
    :license: BSD, see LICENSE for details.
"""
