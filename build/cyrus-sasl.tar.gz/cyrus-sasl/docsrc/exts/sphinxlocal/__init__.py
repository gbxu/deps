# -*- coding: utf-8 -*-
"""
    sphinxlocal
    ~~~~~~~~~~~

    Custom docutils components.

    :copyright: Copywrite 2015 by Nic Bernstein <nic@onlight.com>
    :license: BSD, see LICENSE for details.
"""
